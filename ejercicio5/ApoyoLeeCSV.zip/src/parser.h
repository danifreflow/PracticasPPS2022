#define MaxLinea 2048
#define MaxCampos 15


int parser(FILE * file);
